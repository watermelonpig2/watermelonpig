import os
import numpy as np
import torch
import argparse

def save_npz(file_path, x_data, y_data, x_offsets, y_offsets):
    np.savez_compressed(
        file_path,
        x=x_data.cpu().numpy(),
        y=y_data.cpu().numpy(),
        x_offsets=x_offsets.reshape(list(x_offsets.shape) + [1]),
        y_offsets=y_offsets.reshape(list(y_offsets.shape) + [1]),
    )

def process_batches(batch_dir, start_batch, end_batch):
    all_x, all_y = [], []

    for i in range(start_batch, end_batch):
        batch_file = os.path.join(batch_dir, f"batch_{i}.npz")
        with np.load(batch_file) as data:
            x_data = torch.tensor(data['x']).cuda()
            y_data = torch.tensor(data['y']).cuda()

            all_x.append(x_data)
            all_y.append(y_data)

    all_x = torch.cat(all_x, dim=0)
    all_y = torch.cat(all_y, dim=0)

    return all_x, all_y

def main(args):
    batch_dir = args.batch_dir
    output_dir = args.output_dir
    batch_size = args.batch_size
    num_batches = args.num_batches

    # Assuming all batch files have the same x_offsets and y_offsets
    with np.load(os.path.join(batch_dir, f"batch_0.npz")) as data:
        x_offsets = data['x_offsets']
        y_offsets = data['y_offsets']

    for start_batch in range(0, num_batches, batch_size):
        end_batch = min(start_batch + batch_size, num_batches)
        print(f"Processing batches from {start_batch} to {end_batch}")

        all_x, all_y = process_batches(batch_dir, start_batch, end_batch)

        # Save all processed data for later global split
        save_npz(os.path.join(output_dir, f"all_{start_batch}_{end_batch}.npz"), all_x, all_y, x_offsets, y_offsets)

        # Clear the cache
        del all_x
        del all_y
        torch.cuda.empty_cache()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_dir", type=str, default="/home/dsj22/LargeST-main/data/batch_gla_splitedata/GLA_2019", help="Directory with batch files.")
    parser.add_argument("--output_dir", type=str, default="/home/dsj22/LargeST-main/data/glatest2019", help="Output directory.")
    parser.add_argument("--num_batches", type=int, default=350, help="Number of batch files.")
    parser.add_argument("--batch_size", type=int, default=10, help="Number of batches to process at once.")

    args = parser.parse_args()
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)

    main(args)
