import os
import numpy as np
import torch
import torch.nn as nn

class DataProcessor(nn.Module):
    def __init__(self):
        super(DataProcessor, self).__init__()

    def forward(self, x, y):
        return x.cuda(), y.cuda()

def save_npz(file_path, x_data, y_data, x_offsets, y_offsets):
    np.savez_compressed(
        file_path,
        x=x_data.cpu().numpy(),
        y=y_data.cpu().numpy(),
        x_offsets=x_offsets.reshape(list(x_offsets.shape) + [1]),
        y_offsets=y_offsets.reshape(list(y_offsets.shape) + [1]),
    )

def process_and_split_batches(batch_dir, output_dir, num_batches, batch_size, train_ratio=0.7, val_ratio=0.2, x_offsets=None, y_offsets=None):
    train_x, train_y, val_x, val_y, test_x, test_y = [], [], [], [], [], []

    # Initialize the model and DataParallel wrapper
    model = DataProcessor()
    model = nn.DataParallel(model)
    model.cuda()

    for i in range(0, num_batches, batch_size):
        end_batch = min(i + batch_size, num_batches)
        batch_file = os.path.join(batch_dir, f"all_{i}_{end_batch}.npz")
        
        if not os.path.exists(batch_file):
            print(f"Batch file {batch_file} does not exist. Skipping.")
            continue

        with np.load(batch_file) as data:
            x_data = torch.tensor(data['x'])
            y_data = torch.tensor(data['y'])

            x_data, y_data = model(x_data, y_data)
            
            num_samples = x_data.shape[0]
            num_train = int(num_samples * train_ratio)
            num_val = int(num_samples * val_ratio)
            num_test = num_samples - num_train - num_val

            train_x.append(x_data[:num_train].cpu())
            train_y.append(y_data[:num_train].cpu())
            val_x.append(x_data[num_train:num_train + num_val].cpu())
            val_y.append(y_data[num_train:num_train + num_val].cpu())
            test_x.append(x_data[num_train + num_val:].cpu())
            test_y.append(y_data[num_train + num_val:].cpu())

            del x_data, y_data
            torch.cuda.empty_cache()

            # Save splits progressively to avoid memory overload
            if len(train_x) >= batch_size:
                save_partial_split(output_dir, 'train', train_x, train_y, x_offsets, y_offsets)
                train_x, train_y = [], []

            if len(val_x) >= batch_size:
                save_partial_split(output_dir, 'val', val_x, val_y, x_offsets, y_offsets)
                val_x, val_y = [], []

            if len(test_x) >= batch_size:
                save_partial_split(output_dir, 'test', test_x, test_y, x_offsets, y_offsets)
                test_x, test_y = [], []

    # Save remaining data
    if train_x:
        save_partial_split(output_dir, 'train', train_x, train_y, x_offsets, y_offsets)

    if val_x:
        save_partial_split(output_dir, 'val', val_x, val_y, x_offsets, y_offsets)

    if test_x:
        save_partial_split(output_dir, 'test', test_x, test_y, x_offsets, y_offsets)

def save_partial_split(output_dir, split_name, x_data, y_data, x_offsets, y_offsets):
    x_data = torch.cat(x_data, dim=0)
    y_data = torch.cat(y_data, dim=0)
    save_npz(os.path.join(output_dir, f"{split_name}.npz"), x_data, y_data, x_offsets, y_offsets)

def main():
    batch_dir = "/home/dsj22/LargeST-main/data/glatest2019"  # Specify the directory containing the batch files
    output_dir = "/home/dsj22/LargeST-main/dyngwn_meta-la/DynGWN/GLA/GLA_train_val_test2019"
    num_batches = 350
    batch_size = 10

    # Load the offsets from the first batch to reuse in saving splits
    first_batch_file = os.path.join(batch_dir, f"all_0_{batch_size}.npz")
    if not os.path.exists(first_batch_file):
        raise FileNotFoundError(f"First batch file {first_batch_file} does not exist.")
    
    with np.load(first_batch_file) as data:
        x_offsets = data['x_offsets']
        y_offsets = data['y_offsets']

    process_and_split_batches(batch_dir, output_dir, num_batches, batch_size, x_offsets=x_offsets, y_offsets=y_offsets)

if __name__ == "__main__":
    main()
